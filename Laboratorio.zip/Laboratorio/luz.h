#ifndef LUZ_H
#define LUZ_H
#include "extra.h"

class Luz
{
public:
    static GLfloat *lightPosition;
    Luz();
    ~Luz();
    static void inicializar();



};

#endif // LUZ_H
